export const env: { [s: string]: (string | null); } = {
  'npm_package_version': '1.0.0'
};
