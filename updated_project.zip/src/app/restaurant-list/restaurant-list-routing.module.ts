import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RestaurantListComponent } from './restaurant-list.component';
import { Shell } from '@app/shell/shell.service';
import { RestaurantDetailsComponent } from './components/restaurant-details/restaurant-details.component';
import { AddRestaurantComponent } from './components/add-restaurant/add-restaurant.component';
import { EditRestaurantComponent } from './components/edit-restaurant/edit-restaurant.component';

const routes: Routes = [
  Shell.childRoutes([
    { path: '', redirectTo: 'restaurant', pathMatch: 'full' },
    {
      path: 'restaurant',
      component: RestaurantListComponent,
    },
    {
      path: 'restaurant-details',
      component: RestaurantDetailsComponent,
    },
    {
      path: 'add-restaurant',
      component: AddRestaurantComponent,
    },
    {
      path: 'edit-restaurant',
      component: EditRestaurantComponent
    }
  ])
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RestaurantListRoutingModule {}
