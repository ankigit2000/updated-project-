import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';
import { RestaurantListService } from './restaurant-list.service';

@Component({
  selector: 'app-restaurant-list',
  templateUrl: './restaurant-list.component.html',
  styleUrls: ['./restaurant-list.component.scss'],
})
export class RestaurantListComponent implements OnInit {
  restaurantListData: any[] = [];
  searchString: string = '';
  debounceSearch = new Subject<string>();
  constructor(private restaurantService: RestaurantListService, private router: Router) {}
  ngOnInit(): void {
    this.getRestaurants(null);
    this.debounceSearch.pipe(debounceTime(400), distinctUntilChanged()).subscribe((value: any) => {
      this.getRestaurants(value);
    });
  }

  private getRestaurants(searchString: string | null) {
    console.log(searchString);
    this.restaurantService.getRestaurants(this.searchString).subscribe({
      next: (data) => {
        this.restaurantListData = data;
      },
      error: (err) => {
        this.restaurantListData = [];
      },
    });
  }

  clearSearchString() {
    this.debounceSearch.next('');
    this.searchString = '';
  }

  routeToAddRestaurant() {
    this.router.navigate(['add-restaurant']);
  }

  routeToEditRestaurant(data: any) {
    this.router.navigate(['edit-restaurant'], {
      queryParams: {
        id: data?.id,
      },
    });
  }

  deleteRestaurant(data: any) {
    this.restaurantService.deleteRestaurant(data?.id).subscribe({
      next: (data) => {
        this.getRestaurants(null);
      },
    });
  }

  routeToViewRestaurant(data: any) {
    this.router.navigate(['restaurant-details'], {
      queryParams: {
        id: data?.id,
      },
    });
  }
}
