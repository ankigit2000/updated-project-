import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { rest } from 'cypress/types/lodash';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RestaurantListDALService {
  restaurants = [
    {
      id: '1',
      name: 'Restaurant 1',
      location: 'Location 1',
      specialty: 'Specialty 1',
      menu: {
        break_fast: [
          {
            id: 1,
            name: 'Item1',
            type: 'Break Fast',
            price: 10
          },
          {
            id: 2,
            name: 'Item2',
            type: 'Break Fast',
            price: 20
          },
          {
            id: 3,
            name: 'Item3',
            type: 'Break Fast',
            price: 30
          },
        ],
        lunch: [
          {
            id: 4,
            name: 'Item4',
            type: 'Main Course',
            price: 50
          },
          {
            id: 5,
            name: 'Item5',
            type: 'Lunch',
            price: 60
          },
          {
            id: 6,
            name: 'Item6',
            type: 'Main Course',
            price: 100
          },
        ],
        dinner: [
          {
            id: 7,
            name: 'Item7',
            type: 'Dinner',
            price: 100
          },
          {
            id: 8,
            name: 'Item8',
            type: 'Dinner',
            price: 200
          },
          {
            id: 9,
            name: 'Item9',
            type: 'Dinner',
            price: 190
          },
        ],
      },
      additionalFeatures: ['Feature 1', 'Feature 2'],
    },
    {
      id: '2',
      name: 'Restaurant 2',
      location: 'Location 2',
      specialty: 'Specialty 2',
      menu: {
        break_fast: [
          {
            id: 1,
            name: 'Item1',
            type: 'Break Fast',
            price: 10
          },
          {
            id: 2,
            name: 'Item2',
            type: 'Break Fast',
            price: 20
          },
          {
            id: 3,
            name: 'Item3',
            type: 'Break Fast',
            price: 30
          },
        ],
        lunch: [
          {
            id: 4,
            name: 'Item4',
            type: 'Lunch',
            price: 50
          },
          {
            id: 5,
            name: 'Item5',
            type: 'Lunch',
            price: 60
          },
          {
            id: 6,
            name: 'Item6',
            type: 'Lunch',
            price: 100
          },
        ],
        dinner: [
          {
            id: 7,
            name: 'Item7',
            type: 'Dinner',
            price: 100
          },
          {
            id: 8,
            name: 'Item8',
            type: 'Dinner',
            price: 200
          },
          {
            id: 9,
            name: 'Item9',
            type: 'Dinner',
            price: 190
          },
        ],
      },
      additionalFeatures: ['Feature 1', 'Feature 2'],
    },
  ];
  constructor(private http: HttpClient) {}
  /**
   * fetch restaurants from API
   * @returns restauratns list
   */
  fetchRestaurants(searchString: string): Observable<any> {
    if (!searchString) {
      return of(this.restaurants);
    } else {
      const filtered = this.restaurants.filter((restaurant) => restaurant?.name?.indexOf(searchString) != -1);
      return of(filtered);
    }
  }

  addRestaurant(value: any): Observable<any> {
    return new Observable((observer) => {
      // TODO REMOVE THIS FORMATTER
      this.restaurants.push(value);
      observer.next(value);
      observer.complete();
    });
  }
  fetchRestaurantById(id: string): Observable<any> {
    return new Observable((observer) => {
      // TODO REMOVE THIS FORMATTER
      const restById = this.restaurants.find((value) => value?.id === id);
      observer.next(restById);
      observer.complete();
    });
  }

  updateRestaurantById(id: string, data: any): Observable<any> {
    console.log(
      '🚀 ~ file: restaurant-list-dal.service.ts:60 ~ RestaurantListDALService ~ updateRestaurantById ~ id',
      id
    );
    return new Observable((observer) => {
      // TODO REMOVE THIS FORMATTER
      const restByIdIndex = this.restaurants.findIndex((value) => value?.id === id);
      console.log(
        '🚀 ~ file: restaurant-list-dal.service.ts:63 ~ RestaurantListDALService ~ returnnewObservable ~ restByIdIndex',
        restByIdIndex
      );
      this.restaurants[restByIdIndex] = data;
      observer.next(this.restaurants[restByIdIndex]);
      observer.complete();
    });
  }

  deleteRestaurant(id: string): Observable<any> {
    return new Observable((observer) => {
      const restByIdIndex = this.restaurants.findIndex((value) => value?.id === id);
      this.restaurants.splice(restByIdIndex, 1);
      observer.next(this.restaurants);
    });
  }

  getMenuItems(id: string, menuType: string): Observable<any> {
    return new Observable((observer) => {
      const restByIdIndex = this.restaurants.findIndex((value) => value?.id === id);
       observer.next(this.restaurants[restByIdIndex].menu[menuType || 'break_fast'])
    });
  }
}
