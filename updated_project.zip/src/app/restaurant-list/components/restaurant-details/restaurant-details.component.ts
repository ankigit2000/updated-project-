import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RestaurantListService } from '@app/restaurant-list/restaurant-list.service';

@Component({
  selector: 'app-restaurant-details',
  templateUrl: './restaurant-details.component.html',
  styleUrls: ['./restaurant-details.component.scss']
})
export class RestaurantDetailsComponent implements OnInit {
  id: string = '';
  restDetails = {};
  detailsFetched = false;
  menuType = 'break_fast';
  menuList: any[] = [];
  constructor(
    private route: ActivatedRoute,
    private restaurantListService: RestaurantListService
  ) {
    this.id = this.route.snapshot.queryParamMap.get('id') as string;
  }

  ngOnInit(): void {
    this.getRestarutantDetails();
    this.getMenuList();
  }

  getRestarutantDetails() {
    this.restaurantListService.fetchRestaurantById(this.id).subscribe({
      next: (data) => {
        console.log(data)
        this.restDetails = data;
        this.detailsFetched = true;
      }
    })
  }

  getMenuList() {
    this.restaurantListService.getMenuItems(this.id, this.menuType).subscribe({
      next: (data) => {
        this.menuList = data;
      }
    })
  }

  updateOptions() {
    this.getMenuList();
  }
}
