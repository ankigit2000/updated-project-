import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { RestaurantListService } from '@app/restaurant-list/restaurant-list.service';

@Component({
  selector: 'app-add-restaurant',
  templateUrl: './add-restaurant.component.html',
  styleUrls: ['./add-restaurant.component.scss'],
})
export class AddRestaurantComponent implements OnInit {
  @Input() pageType = 'add';
  @Input() formValues = {};
  @Input() restId = '';
  addRestaurantForm = new FormGroup({
    name: new FormControl('', Validators.required),
    city: new FormControl('', Validators.required),
    state: new FormControl('', Validators.required),
    specialty: new FormControl(''),
    additionalFeatures: new FormControl(''),
  });
  constructor(private restaurantListService: RestaurantListService) {}

  ngOnInit(): void {
    if (this.pageType === 'edit') {
      this.addRestaurantForm.patchValue(this.formValues);
    }
  }

  addRestaurant() {
    this.restaurantListService.addRestaurant(this.addRestaurantForm.value).subscribe({
      next: () => {
        this.addRestaurantForm.reset();
      },
    });
  }
  updateRestauarant() {
    this.restaurantListService.updateRestaurant(this.restId, this.addRestaurantForm.value).subscribe({
      next: () => {
        this.addRestaurantForm.reset();
      },
    });
  }
  handleSubmit() {
    this.pageType === 'edit' ? this.updateRestauarant() : this.addRestaurant();
  }
}
